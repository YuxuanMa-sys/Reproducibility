Bornholt18.yaml BuildAndTestSuccess
ShahKZ17.yaml BuildAndTestSuccess

There's something wrong with the validator, so I didn't write the yaml files. 

20 / 12

If you couldn't get the Kang et al. Dockerfile it isn't a build success for this week. But don't be worried; you have enough points for this week and some to spare. I will treat your Kang et al. work as a head-start on next week.

s
# This two are already included in progress4.md. I had already translated this progress report that week, just not updating this file. 