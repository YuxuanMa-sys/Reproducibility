## After regrading
yuxuanm4: mp2.md: 5.0 (Translations present)
yuxuanm4: progress1.md: 5.0 (Translations present)
yuxuanm4: total 10.0