I am fine to have my work publicly on GitHub.com. My GitHub.com username is on the next line:
YuxuanMa-sys