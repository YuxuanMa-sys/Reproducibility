Bornholt18.yaml BuildAndTestSuccess
CaiGZACOTTW18.yaml BuildAndTestSuccess
WeiZZCMLFC23.yaml BuildAndTestSuccess
YangLW12.yaml BuildAndTestSuccess
FengKRR12/ BuildAndTestSuccess
BegoliCHML18.yaml BuildAndTestSuccess
GehrMTVWV18/ BuildAndTestSuccess
ShahKZ17.yaml BuildAndTestSuccess
0001ST18.yaml BuildAndTestSuccess
PulteFDFSS18.yaml BuildAndTestSuccess
LimFAK11/ BuildAndTestSuccess
KangKSLPSKCCHY18.yaml TestFail
KaiserZKRD18.yaml BuildCrash
LeeHJLRL18.yaml BuildCrash
MbakoyiannisTK18.yaml BuildCrash
PrakriyaCBSC24.yaml BuildCrash
JinLJMSHZ18.yaml BuildCrash

If you don't lose too many points in progress 4, you will have 200 / 92 points cumulatively.
