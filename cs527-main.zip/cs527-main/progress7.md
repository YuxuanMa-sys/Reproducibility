0001ST18.yaml BuildAndTestSuccess
PulteFDFSS18.yaml TestIncomplete
KangKSLPSKCCHY18.yaml BuildAndTestSuccess

Those are fixed from previous ones using the new schema. (different base image) I think I have enough points. 
## After regrading
yuxuanm4: 0001ST18.yaml: 10.0 (BuildAndTestSuccess)
yuxuanm4: KangKSLPSKCCHY18.yaml: 10.0 (BuildAndTestSuccess)
yuxuanm4: PulteFDFSS18.yaml: 5.0 (TestIncomplete)
yuxuanm4: total 25.0