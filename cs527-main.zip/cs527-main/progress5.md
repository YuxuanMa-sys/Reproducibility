AlavisamaniVA0Q24.yaml BuildAndTestSuccess
ZagieboyloSMS23.yaml BuildAndTestSuccess
YeJC24.yaml BuildCrash
GodboleCMS24.yaml TestFail

## After regrading
yuxuanm4: AlavisamaniVA0Q24.yaml: 10.0 (BuildAndTestSuccess)
yuxuanm4: GodboleCMS24.yaml: 5.0 (TestFail)
yuxuanm4: YeJC24.yaml: 5.0 (BuildCrash)
yuxuanm4: ZagieboyloSMS23.yaml: 10.0 (BuildAndTestSuccess)
yuxuanm4: total 30.0