BegoliCHML18.yaml BuildAndTestSuccess
KaiserZKRD18.yaml BuildCrash

----

I did more last week.

15 / 20

Due to there not being enough bibcodes this week, you may apply "excess" points from past or future weeks to this grade.

# This two are already included in progress4.md. I had already translated this progress report that week, just not updating this file. 